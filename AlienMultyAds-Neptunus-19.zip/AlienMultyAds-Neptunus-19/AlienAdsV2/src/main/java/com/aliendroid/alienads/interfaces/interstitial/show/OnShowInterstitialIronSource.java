package com.aliendroid.alienads.interfaces.interstitial.show;

public interface OnShowInterstitialIronSource {
    void onAdSuccess();
    void onAdFailedShow();
}
