package com.aliendroid.alienads.interfaces.banner;

public interface OnLoadBannerFacebook {
    void onError();
    void onAdLoaded();
    void onAdClicked();
    void onLoggingImpression();
}
