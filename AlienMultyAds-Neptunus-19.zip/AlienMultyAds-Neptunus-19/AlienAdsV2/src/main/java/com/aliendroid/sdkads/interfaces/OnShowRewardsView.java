package com.aliendroid.sdkads.interfaces;

public interface OnShowRewardsView {
    void onAdSuccess();
    void onAdFailedShow();
}
