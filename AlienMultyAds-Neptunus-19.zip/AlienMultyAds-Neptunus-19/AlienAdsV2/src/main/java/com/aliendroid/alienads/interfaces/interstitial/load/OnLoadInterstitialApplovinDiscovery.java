package com.aliendroid.alienads.interfaces.interstitial.load;

public interface OnLoadInterstitialApplovinDiscovery {
    void adReceived();
    void failedToReceiveAd(String error);
}
