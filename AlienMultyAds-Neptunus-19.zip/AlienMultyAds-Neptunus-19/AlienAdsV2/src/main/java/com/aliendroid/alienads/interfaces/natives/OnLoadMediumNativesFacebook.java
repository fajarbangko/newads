package com.aliendroid.alienads.interfaces.natives;

public interface OnLoadMediumNativesFacebook {
    void onMediaDownloaded();
    void onError(String error);
    void onAdLoaded();

}
