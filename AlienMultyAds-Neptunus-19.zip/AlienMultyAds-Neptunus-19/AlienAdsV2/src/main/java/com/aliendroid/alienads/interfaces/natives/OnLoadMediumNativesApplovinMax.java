package com.aliendroid.alienads.interfaces.natives;

public interface OnLoadMediumNativesApplovinMax {
    void onNativeAdLoaded();
    void onNativeAdLoadFailed(String error);
    void onNativeAdClicked();

}
