package com.aliendroid.alienads.interfaces.interstitial.show;

public interface OnShowInterstitialAlienView {
    void onAdSuccess();
    void onAdFailedShow();
}
