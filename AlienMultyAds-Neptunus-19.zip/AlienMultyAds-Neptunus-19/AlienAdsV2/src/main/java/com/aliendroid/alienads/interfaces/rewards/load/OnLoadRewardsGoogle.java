package com.aliendroid.alienads.interfaces.rewards.load;

public interface OnLoadRewardsGoogle {
    void onAdFailedToLoad();
    void onAdLoaded(String error);

}
