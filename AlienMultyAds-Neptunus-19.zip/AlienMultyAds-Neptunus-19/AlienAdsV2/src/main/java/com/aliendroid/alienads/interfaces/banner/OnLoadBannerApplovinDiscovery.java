package com.aliendroid.alienads.interfaces.banner;

public interface OnLoadBannerApplovinDiscovery {
    void adReceived();
    void failedToReceiveAd();
}
