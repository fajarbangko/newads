package com.aliendroid.alienads.interfaces.natives;

public interface OnLoadMediumNativesAlien {
    void onNativeAdLoaded();
    void onNativeAdClicked();
    void onNativeAdFailedToLoad();

}
