package com.aliendroid.alienads.interfaces.interstitial.show;

public interface OnShowInterstitialAlienMediation {
    void onAdSuccess();
    void onAdFailedShow();
}
