package com.aliendroid.alienads.interfaces.interstitial.show;

public interface OnShowInterstitialGoogle {
    void onAdSuccess();
    void onAdFailedShow();
}
