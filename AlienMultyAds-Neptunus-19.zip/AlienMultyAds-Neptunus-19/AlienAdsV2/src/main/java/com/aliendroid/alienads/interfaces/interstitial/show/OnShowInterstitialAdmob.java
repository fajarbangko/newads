package com.aliendroid.alienads.interfaces.interstitial.show;

public interface OnShowInterstitialAdmob {
    void onAdSuccess();
    void onAdFailedShow();
}
