package com.aliendroid.alienads.interfaces.interstitial.load;

public interface OnLoadInterstitialAdmob {
    void onInterstitialAdLoaded();
    void onInterstitialAdFailedToLoad(String error);
}
