package com.aliendroid.alienads.interfaces.natives;

public interface OnLoadSmallNativesAlien {
    void onNativeAdLoaded();
    void onNativeAdClicked();
    void onNativeAdFailedToLoad();

}
