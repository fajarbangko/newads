package com.aliendroid.alienads.interfaces.interstitial.load;

public interface OnLoadInterstitialAlienMediation {
    void onInterstitialAdLoaded();
    void onInterstitialAdClosed();
    void onInterstitialAdClicked();
    void onInterstitialAdFailedToLoad();
}
