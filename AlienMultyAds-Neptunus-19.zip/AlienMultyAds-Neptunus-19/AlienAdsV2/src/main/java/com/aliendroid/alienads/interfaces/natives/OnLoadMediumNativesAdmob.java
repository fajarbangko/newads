package com.aliendroid.alienads.interfaces.natives;

public interface OnLoadMediumNativesAdmob {
    void onNativeAdLoaded();
    void onAdFailedToLoad(String error);

}
