package com.aliendroid.sdkads.interfaces;


public interface OnConnectedListener {
    void onAppConnected();
    void onAppFailed(String error);
}
