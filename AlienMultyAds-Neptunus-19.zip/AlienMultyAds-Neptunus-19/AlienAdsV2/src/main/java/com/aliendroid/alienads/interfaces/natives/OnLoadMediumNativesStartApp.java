package com.aliendroid.alienads.interfaces.natives;

public interface OnLoadMediumNativesStartApp {
    void onReceiveAd();
    void onFailedToReceiveAd(String error);

}
