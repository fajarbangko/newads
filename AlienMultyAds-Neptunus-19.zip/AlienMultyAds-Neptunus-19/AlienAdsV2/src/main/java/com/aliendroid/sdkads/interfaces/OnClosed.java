package com.aliendroid.sdkads.interfaces;

public interface OnClosed {
    void onAdClosed();
}
