package com.aliendroid.alienads.interfaces.rewards.show;

public interface OnShowRewardsGoogle {
    void onUserEarnedReward();
}
