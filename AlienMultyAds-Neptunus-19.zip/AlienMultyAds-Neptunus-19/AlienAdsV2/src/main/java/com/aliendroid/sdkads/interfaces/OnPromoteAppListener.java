package com.aliendroid.sdkads.interfaces;

public interface OnPromoteAppListener {
    void onInitializeSuccessful();
    void onInitializeFailed(String error);
}
