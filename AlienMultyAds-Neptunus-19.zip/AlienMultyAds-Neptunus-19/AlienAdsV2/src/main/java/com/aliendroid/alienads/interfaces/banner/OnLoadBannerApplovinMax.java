package com.aliendroid.alienads.interfaces.banner;

public interface OnLoadBannerApplovinMax {
    void onAdExpanded();
    void onAdCollapsed();
    void onAdLoaded();
    void onAdHidden();
    void onAdDisplayed();
    void onAdClicked();
    void onAdLoadFailed();
    void onAdDisplayFailed();
}
