package com.aliendroid.sdkads.interfaces;

public interface OnShowInterstitialView {
    void onAdSuccess();
    void onAdFailedShow();
}
