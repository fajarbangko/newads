package com.aliendroid.alienads.interfaces.natives;

public interface OnLoadSmallNativesApplovinMax {
    void onNativeAdLoaded();
    void onNativeAdLoadFailed(String error);
    void onNativeAdClicked();

}
