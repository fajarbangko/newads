package com.aliendroid.alienads.interfaces.natives;

public interface OnLoadSmallNativesStartApp {
    void onReceiveAd();
    void onFailedToReceiveAd(String error);

}
