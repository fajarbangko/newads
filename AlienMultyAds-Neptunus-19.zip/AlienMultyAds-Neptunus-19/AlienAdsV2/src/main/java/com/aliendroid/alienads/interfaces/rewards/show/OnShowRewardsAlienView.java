package com.aliendroid.alienads.interfaces.rewards.show;

public interface OnShowRewardsAlienView {
    void onAdSuccess();
    void onAdFailedShow();
}
