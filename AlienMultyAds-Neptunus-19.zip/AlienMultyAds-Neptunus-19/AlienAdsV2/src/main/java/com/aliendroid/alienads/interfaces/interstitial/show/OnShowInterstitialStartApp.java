package com.aliendroid.alienads.interfaces.interstitial.show;

public interface OnShowInterstitialStartApp {
    void adHidden();
    void adDisplayed();
    void adClicked();
    void adNotDisplayed();
}
