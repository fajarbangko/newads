package com.aliendroid.alienads.interfaces.natives;

public interface OnLoadSmallNativesFacebook {
    void onMediaDownloaded();
    void onError(String error);
    void onAdLoaded();

}
