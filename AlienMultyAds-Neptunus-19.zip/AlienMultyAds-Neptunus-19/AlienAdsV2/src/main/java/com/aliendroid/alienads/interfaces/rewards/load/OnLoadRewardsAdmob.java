package com.aliendroid.alienads.interfaces.rewards.load;

public interface OnLoadRewardsAdmob {
    void onAdFailedToLoad();
    void onAdLoaded(String error);

}
