package com.aliendroid.alienads.interfaces.rewards.show;

public interface OnShowRewardsAdmob {
    void onUserEarnedReward();
}
