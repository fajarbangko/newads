package com.aliendroid.alienads.interfaces.interstitial.show;

public interface OnShowInterstitialFacebook {
    void onAdSuccess();
    void onAdFailedShow();
}
