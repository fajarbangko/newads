package com.aliendroid.alienads.interfaces.interstitial.load;

public interface OnLoadInterstitialApplovinMax {
    void adReceived();
    void failedToReceiveAd(String error);
}
