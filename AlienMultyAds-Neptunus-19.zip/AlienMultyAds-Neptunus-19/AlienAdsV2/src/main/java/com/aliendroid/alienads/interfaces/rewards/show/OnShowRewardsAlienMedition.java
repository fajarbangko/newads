package com.aliendroid.alienads.interfaces.rewards.show;

public interface OnShowRewardsAlienMedition {
    void onAdSuccess();
    void onAdFailedShow();
}
