package com.aliendroid.alienads.interfaces.natives;

public interface OnLoadSmallNativesAdmob {
    void onNativeAdLoaded();
    void onAdFailedToLoad(String error);

}
