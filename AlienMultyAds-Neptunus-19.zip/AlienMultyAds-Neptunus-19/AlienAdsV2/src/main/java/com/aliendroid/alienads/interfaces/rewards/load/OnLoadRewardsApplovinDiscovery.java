package com.aliendroid.alienads.interfaces.rewards.load;

public interface OnLoadRewardsApplovinDiscovery {
    void adReceived();
    void failedToReceiveAd(String error);

}
