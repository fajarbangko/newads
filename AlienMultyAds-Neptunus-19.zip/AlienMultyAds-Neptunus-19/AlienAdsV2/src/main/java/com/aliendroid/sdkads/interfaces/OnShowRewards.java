package com.aliendroid.sdkads.interfaces;

public interface OnShowRewards {
    void onAdSuccess();
    void onAdFailedShow();
}
