package com.aliendroid.alienads.interfaces.open;

public interface OnShowOpenAppAdmob {
    void onAdDismissedFullScreenContent();
    void onAdFailedToShowFullScreenContent();
    void onAdShowedFullScreenContent();
}
