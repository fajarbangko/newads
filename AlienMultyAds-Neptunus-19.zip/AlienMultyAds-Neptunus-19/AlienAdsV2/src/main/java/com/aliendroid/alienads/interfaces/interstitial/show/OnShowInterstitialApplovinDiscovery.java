package com.aliendroid.alienads.interfaces.interstitial.show;

public interface OnShowInterstitialApplovinDiscovery {
    void onAdSuccess();
    void onAdFailedShow();
}
