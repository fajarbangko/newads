package com.aliendroid.alienads.interfaces.rewards.load;

public interface OnLoadRewardsStartApp {
    void onVideoCompleted();
    void onReceiveAd();
    void onFailedToReceiveAd();
}
