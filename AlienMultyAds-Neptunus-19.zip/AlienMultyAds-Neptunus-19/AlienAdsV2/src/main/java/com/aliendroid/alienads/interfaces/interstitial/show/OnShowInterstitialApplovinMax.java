package com.aliendroid.alienads.interfaces.interstitial.show;

public interface OnShowInterstitialApplovinMax {
    void onAdSuccess();
    void onAdFailedShow();
}
