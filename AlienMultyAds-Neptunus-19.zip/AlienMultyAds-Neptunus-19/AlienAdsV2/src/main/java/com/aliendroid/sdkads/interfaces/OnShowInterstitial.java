package com.aliendroid.sdkads.interfaces;

public interface OnShowInterstitial {
    void onAdSuccess();
    void onAdFailedShow();
}
