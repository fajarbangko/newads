package com.aliendroid.alienads.interfaces.open;

public interface OnLoadOpenAppAdmob {
    void onAdLoaded();
    void onAdFailedToLoad();
}
