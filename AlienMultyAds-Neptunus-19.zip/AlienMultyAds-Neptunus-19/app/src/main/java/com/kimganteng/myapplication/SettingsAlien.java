package com.kimganteng.myapplication;

import java.security.PublicKey;

public class SettingsAlien {

    public static  String Select_Main_Ads ="ADMOB";
    public static  String Select_Backup_Ads ="APPLOVIN-M";

    public static String  MainIntertitial ="ca-app-pub-3940256099942544/1033173712";
    public static  String BackupIntertitial ="133149992";

    public static  String MainBanner="ca-app-pub-3940256099942544/6300978111";
    public static  String BackupBanner="133149963";

    public static String MainNatives ="ca-app-pub-3940256099942544/2247696110";
    public static String BackupNatives="133149966";

    public static String MainRewards ="ca-app-pub-3940256099942544/5224354917";
    public static String BackupReward="133149969";

    public static  String Main_Initialize="1100042525";
    public static  String Backup_Initialize="PL610825165122";

    public static String Select_Open_Ads ="1";

    public static boolean ONLOADOPEN = true ;


    /*
    Ads for Aliendroid
     */
    public static String AppIDMediationAds ="1100042525";
    public static String AppIDViewAds ="PL610825165122";
}
